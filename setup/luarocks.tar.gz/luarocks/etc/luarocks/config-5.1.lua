rocks_trees = {
   [[/opt/luarocks]]
}
